<?php
/**
 * MilkCore Token Manager
 * 
 * Classe PHP per la gestione dei token JWT nelle API MilkCore.
 * Si occupa SOLO di:
 * - Login per ottenere token
 * - Refresh del token
 * - Verifica validità token
 * - Gestione in memoria del token corrente
 * 
 * Il salvataggio/caricamento è responsabilità di chi usa la classe.
 * 
 * @author Giulio Pandolfelli
 * @version 1.0.0
 */

class MilkCoreTokenManager {
    
    /**
     * URL base dell'API
     * @var string
     */
    private $api_url;
    
    /**
     * Credenziali di accesso
     * @var array
     */
    private $credentials;
    
    /**
     * Token JWT corrente
     * @var string|null
     */
    private $token;
    
    /**
     * Timestamp di scadenza del token
     * @var int|null
     */
    private $token_expires_at;
    
    /**
     * Margine di sicurezza prima della scadenza (secondi)
     * @var int
     */
    private $refresh_margin;
    
    /**
     * Timeout per le richieste HTTP
     * @var int
     */
    private $timeout;
    
    /**
     * Ultimo errore verificatosi
     * @var string
     */
    private $last_error;
    
    /**
     * Flag per debug
     * @var bool
     */
    private $debug;

    /**
     * Costruttore
     * 
     * @param string $api_url URL base dell'API
     * @param string $username Username per il login
     * @param string $password Password per il login
     * @param array $options Opzioni aggiuntive
     */
    public function __construct($api_url, $username, $password, $options = []) {
        $this->api_url = rtrim($api_url, '/');
        $this->credentials = [
            'username' => $username,
            'password' => $password
        ];
        
        $this->refresh_margin = $options['refresh_margin'] ?? 300; // 5 minuti prima della scadenza
        $this->timeout = $options['timeout'] ?? 30;
        $this->debug = $options['debug'] ?? false;
        
        $this->log("Token Manager inizializzato per API: {$this->api_url}");
    }

    /**
     * Effettua il login e ottiene un nuovo token
     * 
     * @return bool True se il login è riuscito
     */
    public function login() {
        $this->log("Effettuo login per utente: " . $this->credentials['username']);
        
        try {
            $response = $this->make_auth_request('auth/login', 'POST', $this->credentials);
            
            if ($response && isset($response['success']) && $response['success']) {
                $this->set_token_data($response['data']);
                $this->log("Login effettuato con successo");
                return true;
            } else {
                $this->last_error = "Login fallito: " . ($response['message'] ?? 'Errore sconosciuto');
                $this->log($this->last_error);
                return false;
            }
            
        } catch (Exception $e) {
            $this->last_error = "Errore durante il login: " . $e->getMessage();
            $this->log($this->last_error);
            return false;
        }
    }

    /**
     * Rinnova il token corrente
     * 
     * @return bool True se il refresh è riuscito
     */
    public function refresh_token() {
        if (!$this->token) {
            $this->last_error = "Nessun token da rinnovare";
            return false;
        }
        
        $this->log("Rinnovo token...");
        
        try {
            $response = $this->make_auth_request('auth/refresh', 'GET', [], $this->token);
            
            if ($response && isset($response['token'])) {
                $this->set_token_data($response);
                $this->log("Token rinnovato con successo");
                return true;
            } else {
                $this->last_error = "Refresh fallito: " . ($response['message'] ?? 'Errore sconosciuto');
                $this->log($this->last_error);
                return false;
            }
            
        } catch (Exception $e) {
            $this->last_error = "Errore durante refresh: " . $e->getMessage();
            $this->log($this->last_error);
            return false;
        }
    }

    /**
     * Verifica se un token è valido chiamando l'API
     * 
     * @param string|null $token Token da verificare (usa quello corrente se null)
     * @return bool True se il token è valido
     */
    public function verify_token($token = null) {
        $token_to_verify = $token ?? $this->token;
        
        if (!$token_to_verify) {
            $this->last_error = "Nessun token da verificare";
            return false;
        }
        
        try {
            $response = $this->make_auth_request('auth/verify', 'GET', ['token' => $token_to_verify]);
            
            return $response && isset($response['success']) && $response['success'];
            
        } catch (Exception $e) {
            $this->last_error = "Errore durante verifica: " . $e->getMessage();
            return false;
        }
    }

    /**
     * Ottieni il token corrente
     * 
     * @return string|null
     */
    public function get_token() {
        return $this->token;
    }

    /**
     * Imposta un token manualmente (da storage esterno)
     * 
     * @param string $token Token JWT
     * @param int|null $expires_at Timestamp di scadenza (opzionale)
     */
    public function set_token($token, $expires_at = null) {
        $this->token = $token;
        $this->token_expires_at = $expires_at;
        $this->log("Token impostato manualmente");
    }

    /**
     * Pulisce il token dalla memoria
     */
    public function clear_token() {
        $this->token = null;
        $this->token_expires_at = null;
        $this->log("Token cancellato dalla memoria");
    }

    /**
     * Verifica se c'è un token in memoria
     * 
     * @return bool
     */
    public function has_token() {
        return $this->token !== null;
    }

    /**
     * Verifica se il token corrente è ancora valido (controllo scadenza locale)
     * 
     * @return bool
     */
    public function is_token_expired() {
        if (!$this->token || !$this->token_expires_at) {
            return true;
        }
        
        return $this->token_expires_at <= time();
    }

    /**
     * Verifica se il token dovrebbe essere rinnovato (margine di sicurezza)
     * 
     * @return bool
     */
    public function should_refresh() {
        if (!$this->token || !$this->token_expires_at) {
            return false;
        }
        
        $time_to_expiry = $this->token_expires_at - time();
        return $time_to_expiry <= $this->refresh_margin;
    }

    /**
     * Ottieni informazioni sul token corrente
     * 
     * @return array|null
     */
    public function get_token_info() {
        if (!$this->token) {
            return null;
        }
        
        return [
            'token_preview' => substr($this->token, 0, 20) . '...',
            'expires_at' => $this->token_expires_at,
            'expires_in' => $this->token_expires_at ? ($this->token_expires_at - time()) : null,
            'is_expired' => $this->is_token_expired(),
            'should_refresh' => $this->should_refresh(),
            'username' => $this->credentials['username']
        ];
    }

    /**
     * Ottieni l'ultimo errore
     * 
     * @return string
     */
    public function get_last_error() {
        return $this->last_error;
    }

    /**
     * Esegue richieste di autenticazione (login, refresh, verify)
     * 
     * @param string $endpoint Endpoint di autenticazione
     * @param string $method Metodo HTTP
     * @param array $data Dati da inviare
     * @param string|null $auth_token Token per l'autorizzazione
     * @return array|false Risposta decodificata
     */
    private function make_auth_request($endpoint, $method, $data = [], $auth_token = null) {
        $url = $this->api_url . '?page=' . $endpoint;
        
        // Headers di base
        $headers = [
            'Content-Type: application/json',
            'Accept: application/json',
            'User-Agent: MilkCore-TokenManager/1.0.0'
        ];
        
        // Aggiungi token di autorizzazione se fornito
        if ($auth_token) {
            $headers[] = 'Authorization: Bearer ' . $auth_token;
        }
        
        // Gestisci parametri GET
        if ($method === 'GET' && !empty($data)) {
            $url .= '&' . http_build_query($data);
            $data = [];
        }
        
        $ch = curl_init();
        
        curl_setopt_array($ch, [
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT => $this->timeout,
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_HTTPHEADER => $headers,
            CURLOPT_CUSTOMREQUEST => $method
        ]);
        
        // Aggiungi body per POST
        if ($method === 'POST' && !empty($data)) {
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
        }
        
        if ($this->debug) {
            $this->log("Auth Request: $method $url");
            if (!empty($data) && $method !== 'GET') {
                $this->log("Body: " . json_encode($data));
            }
        }
        
        $response = curl_exec($ch);
        $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $curl_error = curl_error($ch);
        
        curl_close($ch);
        
        if ($curl_error) {
            throw new Exception("Errore cURL: $curl_error");
        }
        
        if ($http_code >= 400) {
            throw new Exception("Errore HTTP: $http_code - $response");
        }
        
        if ($this->debug) {
            $this->log("Auth Response ($http_code): $response");
        }
        
        $decoded = json_decode($response, true);
        
        if ($decoded === null && json_last_error() !== JSON_ERROR_NONE) {
            throw new Exception("Errore decodifica JSON: " . json_last_error_msg());
        }
        
        return $decoded;
    }

    /**
     * Imposta i dati del token dalla risposta API
     * 
     * @param array $token_data Dati del token dalla risposta API
     */
    private function set_token_data($token_data) {
        $this->token = $token_data['token'] ?? null;
        $this->token_expires_at = $token_data['expires_at'] ?? null;
    }

    /**
     * Effettua una chiamata API con gestione automatica dei token
     * 
     * Questo metodo si occupa automaticamente di:
     * - Login se non c'è un token
     * - Refresh se il token sta per scadere
     * - Retry della chiamata se il token è scaduto
     * 
     * Esempio di chiamata:
     * 
     * call_api('users/list') →
     * ↓
     * 1. ensure_valid_token() →
     *    - No token? → login()
     *    - Token scade? → refresh_token()
     *    - Refresh fallisce? → login()
     *     ↓
     * 2. make_api_request() →
     *    - Chiama API con token valido
     *     ↓
     * 3. is_token_error_response() →
     *    - Risposta = "token expired"? → retry con nuovo token
     *     ↓
     * 4. Ritorna risposta API
     * 
     * 
     * @param string $endpoint Endpoint API da chiamare (es: 'users/list')
     * @param string $method Metodo HTTP (GET, POST, PUT, DELETE)
     * @param array $data Dati da inviare
     * @param array $options Opzioni aggiuntive per la chiamata
     * @return array|false Risposta dell'API o false in caso di errore
     */
    public function call_api($endpoint, $method = 'GET', $data = [], $options = []) {
        $this->last_error = '';
        $max_retries = $options['max_retries'] ?? 2;
        $retry_count = 0;
        
        while ($retry_count <= $max_retries) {
            try {
                // Step 1: Assicurati di avere un token valido
                if (!$this->ensure_valid_token()) {
                    return false;
                }
                
                // Step 2: Effettua la chiamata API
                $response = $this->make_api_request($endpoint, $method, $data, $options);
                
                // Step 3: Controlla se la risposta indica token scaduto/invalido
                if ($this->is_token_error_response($response)) {
                    $this->log("Token non valido nella risposta, tentativo di recupero...");
                    
                    // Invalida il token corrente e riprova
                    $this->clear_token();
                    
                    if ($retry_count < $max_retries) {
                        $retry_count++;
                        $this->log("Retry #{$retry_count}...");
                        continue;
                    }
                }
                
                return $response;
                
            } catch (Exception $e) {
                $this->last_error = "Errore chiamata API: " . $e->getMessage();
                $this->log($this->last_error);
                
                if ($retry_count < $max_retries) {
                    $retry_count++;
                    sleep($retry_count); // Pausa di 1 secondo tra retry
                    continue;
                }
                
                return false;
            }
        }
        
        $this->last_error = "Numero massimo di tentativi raggiunto per: $endpoint";
        return false;
    }

    /**
     * Assicura che ci sia un token valido per fare chiamate API
     * 
     * @return bool True se il token è pronto per l'uso
     */
    private function ensure_valid_token() {
        // Se non c'è token, fai login
        if (!$this->has_token()) {
            $this->log("Nessun token disponibile, effettuo login...");
            if (!$this->login()) {
                return false;
            }
        }
        
        // Se il token sta per scadere, rinnovalo
        if ($this->should_refresh()) {
            $this->log("Token in scadenza, effettuo refresh...");
            if (!$this->refresh_token()) {
                // Se il refresh fallisce, prova un nuovo login
                $this->log("Refresh fallito, tentativo di nuovo login...");
                $this->clear_token();
                if (!$this->login()) {
                    return false;
                }
            }
        }
        
        return true;
    }

    /**
     * Effettua la chiamata HTTP all'API specifica
     * 
     * @param string $endpoint Endpoint API da chiamare
     * @param string $method Metodo HTTP
     * @param array $data Dati da inviare
     * @param array $options Opzioni per la chiamata
     * @return array|false Risposta decodificata
     */
    private function make_api_request($endpoint, $method, $data, $options = []) {
        $url = $this->api_url . '?page=' . $endpoint;
        
        // Headers
        $headers = [
            'Content-Type: application/json',
            'Accept: application/json',
            'User-Agent: MilkCore-TokenManager/1.0.0'
        ];
        
        // Aggiungi sempre il token per le chiamate API (non auth)
        if ($this->token) {
            $headers[] = 'Authorization: Bearer ' . $this->token;
        }
        
        // Headers personalizzati
        if (isset($options['headers']) && is_array($options['headers'])) {
            $headers = array_merge($headers, $options['headers']);
        }
        
        // Gestisci parametri GET
        if ($method === 'GET' && !empty($data)) {
            $url .= '&' . http_build_query($data);
            $data = [];
        }
        
        $ch = curl_init();
        
        curl_setopt_array($ch, [
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT => $options['timeout'] ?? $this->timeout,
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_HTTPHEADER => $headers,
            CURLOPT_CUSTOMREQUEST => $method
        ]);
        
        // Aggiungi body per metodi che lo supportano
        if (in_array($method, ['POST', 'PUT', 'PATCH', 'DELETE']) && !empty($data)) {
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
        }
        
        if ($this->debug) {
            $this->log("API Request: $method $url");
            if (!empty($data) && $method !== 'GET') {
                $this->log("Body: " . json_encode($data));
            }
        }
        
        $response = curl_exec($ch);
        $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $curl_error = curl_error($ch);
        
        curl_close($ch);
        
        if ($curl_error) {
            throw new Exception("Errore cURL: $curl_error");
        }
        
        if ($http_code >= 400) {
            throw new Exception("Errore HTTP: $http_code - $response");
        }
        
        if ($this->debug) {
            $this->log("API Response ($http_code): " . substr($response, 0, 200) . "...");
        }
        
        $decoded = json_decode($response, true);
        
        if ($decoded === null && json_last_error() !== JSON_ERROR_NONE) {
            throw new Exception("Errore decodifica JSON: " . json_last_error_msg());
        }
        
        return $decoded;
    }

    /**
     * Verifica se la risposta indica un errore di token
     * 
     * @param array|false $response Risposta dell'API
     * @return bool True se la risposta indica un token non valido
     */
    private function is_token_error_response($response) {
        if (!is_array($response)) {
            return false;
        }
        
        // Messaggi di errore che indicano problemi di token
        $token_error_messages = [
            'Invalid or expired token',
            'No authentication token provided',
            'Token expired',
            'Invalid token',
            'Unauthorized',
            'Authentication required'
        ];
        
        if (isset($response['error']) && $response['error']) {
            $message = $response['message'] ?? '';
            foreach ($token_error_messages as $error_msg) {
                if (stripos($message, $error_msg) !== false) {
                    return true;
                }
            }
        }
        
        return false;
    }

    /**
     * Metodi di convenienza per chiamate HTTP comuni
     */
    
    /**
     * Chiamata GET
     * 
     * @param string $endpoint Endpoint API
     * @param array $params Parametri query
     * @param array $options Opzioni aggiuntive
     * @return array|false
     */
    public function get($endpoint, $params = [], $options = []) {
        return $this->call_api($endpoint, 'GET', $params, $options);
    }
    
    /**
     * Chiamata POST
     * 
     * @param string $endpoint Endpoint API
     * @param array $data Dati da inviare
     * @param array $options Opzioni aggiuntive
     * @return array|false
     */
    public function post($endpoint, $data = [], $options = []) {
        return $this->call_api($endpoint, 'POST', $data, $options);
    }
    
    /**
     * Chiamata PUT
     * 
     * @param string $endpoint Endpoint API
     * @param array $data Dati da inviare
     * @param array $options Opzioni aggiuntive
     * @return array|false
     */
    public function put($endpoint, $data = [], $options = []) {
        return $this->call_api($endpoint, 'PUT', $data, $options);
    }
    
    /**
     * Chiamata PATCH
     * 
     * @param string $endpoint Endpoint API
     * @param array $data Dati da inviare
     * @param array $options Opzioni aggiuntive
     * @return array|false
     */
    public function patch($endpoint, $data = [], $options = []) {
        return $this->call_api($endpoint, 'PATCH', $data, $options);
    }
    
    /**
     * Chiamata DELETE
     * 
     * @param string $endpoint Endpoint API
     * @param array $data Dati da inviare
     * @param array $options Opzioni aggiuntive
     * @return array|false
     */
    public function delete($endpoint, $data = [], $options = []) {
        return $this->call_api($endpoint, 'DELETE', $data, $options);
    }


    /**
     * NUOVO METODO: call_api_anonymous
     * Effettua chiamate API senza autenticazione
     */
    public function call_api_anonymous($endpoint, $method = 'GET', $data = [], $options = []) {
        $this->last_error = '';
        $max_retries = $options['max_retries'] ?? 2;
        $retry_count = 0;
        
        while ($retry_count <= $max_retries) {
            try {
                $response = $this->make_anonymous_request($endpoint, $method, $data, $options);
                return $response;
                
            } catch (Exception $e) {
                $this->last_error = "Errore chiamata API anonima: " . $e->getMessage();
                $this->log($this->last_error);
                
                if ($retry_count < $max_retries) {
                    $retry_count++;
                    sleep($retry_count);
                    continue;
                }
                
                return false;
            }
        }
        
        $this->last_error = "Numero massimo di tentativi raggiunto per chiamata anonima: $endpoint";
        return false;
    }

    /**
     * NUOVO METODO: make_anonymous_request
     * Effettua una chiamata HTTP senza token di autenticazione
     */
    private function make_anonymous_request($endpoint, $method, $data, $options = []) {
        $this->log("Effettuo chiamata ANONIMA: $method $endpoint");
        
        $url = $this->api_url . '?page=' . $endpoint;
        
        // Headers per chiamata anonima (senza Authorization)
        $headers = [
            'Content-Type: application/json',
            'Accept: application/json',
            'User-Agent: MilkCore-TokenManager/1.0.0'
        ];
        
        // Headers personalizzati
        if (isset($options['headers']) && is_array($options['headers'])) {
            $headers = array_merge($headers, $options['headers']);
        }
        
        // Gestisci parametri GET
        if ($method === 'GET' && !empty($data)) {
            $url .= '&' . http_build_query($data);
            $data = [];
        }
        
        $ch = curl_init();
        
        curl_setopt_array($ch, [
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT => $options['timeout'] ?? $this->timeout,
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_HTTPHEADER => $headers,
            CURLOPT_CUSTOMREQUEST => $method
        ]);
        
        // Aggiungi body per metodi che lo supportano
        if (in_array($method, ['POST', 'PUT', 'PATCH', 'DELETE']) && !empty($data)) {
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
        }
        
        if ($this->debug) {
            $this->log("Anonymous Request: $method $url");
            if (!empty($data) && $method !== 'GET') {
                $this->log("Body: " . json_encode($data));
            }
        }
        
        $response = curl_exec($ch);
        $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $curl_error = curl_error($ch);
        
        curl_close($ch);
        
        if ($curl_error) {
            throw new Exception("Errore cURL (anonymous): $curl_error");
        }
        
        if ($http_code >= 400) {
            throw new Exception("Errore HTTP (anonymous): $http_code - $response");
        }
        
        if ($this->debug) {
            $this->log("Anonymous Response ($http_code): " . substr($response, 0, 200) . "...");
        }
        
        $decoded = json_decode($response, true);
        
        if ($decoded === null && json_last_error() !== JSON_ERROR_NONE) {
            throw new Exception("Errore decodifica JSON (anonymous): " . json_last_error_msg());
        }
        
        return $decoded;
    }

    /**
     * METODI DI CONVENIENZA PER CHIAMATE ANONIME
     */

    /**
     * GET anonima
     * 
     * @param string $endpoint Endpoint API
     * @param array $params Parametri query
     * @param array $options Opzioni aggiuntive
     * @return array|false
     */
    public function get_anonymous($endpoint, $params = [], $options = []) {
        return $this->call_api_anonymous($endpoint, 'GET', $params, $options);
    }

    /**
     * POST anonima
     * 
     * @param string $endpoint Endpoint API
     * @param array $data Dati da inviare
     * @param array $options Opzioni aggiuntive
     * @return array|false
     */
    public function post_anonymous($endpoint, $data = [], $options = []) {
        return $this->call_api_anonymous($endpoint, 'POST', $data, $options);
    }

    /**
     * PUT anonima
     * 
     * @param string $endpoint Endpoint API
     * @param array $data Dati da inviare
     * @param array $options Opzioni aggiuntive
     * @return array|false
     */
    public function put_anonymous($endpoint, $data = [], $options = []) {
        return $this->call_api_anonymous($endpoint, 'PUT', $data, $options);
    }

    /**
     * PATCH anonima
     * 
     * @param string $endpoint Endpoint API
     * @param array $data Dati da inviare
     * @param array $options Opzioni aggiuntive
     * @return array|false
     */
    public function patch_anonymous($endpoint, $data = [], $options = []) {
        return $this->call_api_anonymous($endpoint, 'PATCH', $data, $options);
    }

    /**
     * Metodo di logging interno
     * 
     * @param string $message Messaggio da loggare
     */
    private function log($message) {
        if ($this->debug) {
            echo "[" . date('Y-m-d H:i:s') . "] TokenManager: $message\n";
        }
    }
}