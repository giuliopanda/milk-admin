<?php
/**
 * Test Suite semplificata per API MilkCore con MilkCoreTokenManager
 */
require_once 'api-token-manager.class.php';

// Configurazione
$config = [
    'api_url' => 'http://localhost/progetto-redcap-statistiche/new_version_250500/api.php',
    'username' => 'admin',
    'password' => 'admin',
    'debug' => true
];

// Colori per output
$colors = [
    'reset' => "\033[0m",
    'red' => "\033[31m",
    'green' => "\033[32m",
    'blue' => "\033[34m",
    'magenta' => "\033[35m"
];

$test_results = [];

/**
 * Funzione di asserzione semplificata
 */
function assert_response($response, $field, $expected, $test_name) {
    global $colors, $test_results;
    
    $actual = $response[$field] ?? null;
    $passed = $actual === $expected;
    $test_results[] = $passed;
    
    echo "  " . ($passed ? $colors['green'] . "✓" : $colors['red'] . "✗") 
         . $colors['reset'] . " $test_name\n";
    
    if (!$passed) {
        echo "    Atteso: " . json_encode($expected) . ", Ottenuto: " . json_encode($actual) . "\n";
    }
}

/**
 * Test suite principale
 */
function run_tests() {
    global $config, $colors;
    
    echo $colors['magenta'] . "\n=== MILK CORE API TEST CON TOKEN MANAGER ===" . $colors['reset'] . "\n\n";
    
    // Inizializza Token Manager
    $api = new MilkCoreTokenManager(
        $config['api_url'],
        $config['username'],
        $config['password'],
        ['debug' => $config['debug']]
    );
    
    // 1. Test endpoint pubblico
    echo $colors['blue'] . "1. Test endpoint pubblico" . $colors['reset'] . "\n";
    $response = $api->get_anonymous('test/info');
    assert_response($response, 'success', true, "Endpoint pubblico");
    
    die;
    // 2. Test lista endpoints
    echo $colors['blue'] . "\n2. Test lista endpoints" . $colors['reset'] . "\n";
    $response = $api->get_anonymous('endpoints');
    assert_response($response, 'success', true, "Lista endpoints");
    
    // 3. Test login automatico (tramite endpoint protetto)
    echo $colors['blue'] . "\n3. Test login automatico" . $colors['reset'] . "\n";
    $response = $api->get('users/profile');
    assert_response($response, 'success', true, "Login automatico dovrebbe funzionare");
    
    if ($api->has_token()) {
        $token_info = $api->get_token_info();
        echo "Token ottenuto: " . $token_info['token_preview'] . "\n";
        echo "Scade tra: " . $token_info['expires_in'] . " secondi\n";
    }
    
    // 4. Test CRUD utenti
    echo $colors['blue'] . "\n4. Test CRUD utenti" . $colors['reset'] . "\n";
    
    // Lista utenti
    $response = $api->get('users/list');
    assert_response($response, 'success', true, "Lista utenti");
    
    // Crea utente
    $test_user = [
        'username' => 'testuser_' . time(),
        'email' => 'test@example.com',
        'password' => 'password123'
    ];
    $response = $api->post('users/create', $test_user);
    assert_response($response, 'success', true, "Creazione utente");
    
    $user_id = $response['data']['user']['id'] ?? null;
    
    if ($user_id) {
        // Mostra utente
        $response = $api->get('users/show', ['id' => $user_id]);
        assert_response($response, 'success', true, "Mostra utente");
        
        // Aggiorna utente
        $response = $api->put('users/update', ['id' => $user_id, 'email' => 'updated@example.com']);
        assert_response($response, 'success', true, "Aggiorna utente");
        
        // Elimina utente
        $response = $api->delete('users/delete', ['id' => $user_id]);
        assert_response($response, 'success', true, "Elimina utente");
    }
    
    // 5. Test refresh token
    echo $colors['blue'] . "\n5. Test refresh token" . $colors['reset'] . "\n";
    $refresh_success = $api->refresh_token();
    echo "  " . ($refresh_success ? $colors['green'] . "✓" : $colors['red'] . "✗") 
         . $colors['reset'] . " Refresh token\n";
    
    // 6. Test gestione errori
    echo $colors['blue'] . "\n6. Test gestione errori" . $colors['reset'] . "\n";
    
    // Endpoint inesistente
    $response = $api->get('nonexistent/endpoint');
    assert_response(['success' => !$response], 'success', true, "Endpoint inesistente dovrebbe fallire");
    
    // Metodo sbagliato
    $response = $api->get('auth/login'); // Login richiede POST
    assert_response(['success' => !$response], 'success', true, "Metodo sbagliato dovrebbe fallire");
    
    // 7. Test resilienza token
    echo $colors['blue'] . "\n7. Test resilienza token" . $colors['reset'] . "\n";
    
    // Simula token scaduto
    $api->set_token('fake_token', time() - 3600);
    $response = $api->get('users/profile');
    assert_response($response, 'success', true, "Dovrebbe recuperare automaticamente");
    
    // Riepilogo
    echo $colors['blue'] . "\n=== RIEPILOGO ===" . $colors['reset'] . "\n";
    global $test_results;
    $passed = array_filter($test_results);
    $failed = count($test_results) - count($passed);
    
    echo "Test passati: " . $colors['green'] . count($passed) . $colors['reset'] . "\n";
    echo "Test falliti: " . ($failed > 0 ? $colors['red'] : $colors['green']) . $failed . $colors['reset'] . "\n";
    
    if ($failed == 0) {
        echo $colors['green'] . "🎉 Tutti i test passati!\n" . $colors['reset'];
    }
}

/**
 * Test singolo endpoint
 */
function test_endpoint($endpoint, $method = 'GET') {
    global $config, $colors;
    
    echo $colors['blue'] . "Test: $method $endpoint\n" . $colors['reset'];
    
    $api = new MilkCoreTokenManager(
        $config['api_url'],
        $config['username'], 
        $config['password'],
        ['debug' => true]
    );
    
    // Dati di test comuni
    $test_data = [
        'users/create' => ['username' => 'newuser', 'email' => 'new@example.com', 'password' => 'pass123'],
        'users/update' => ['id' => 1, 'email' => 'updated@example.com'],
        'users/show' => ['id' => 1],
        'users/delete' => ['id' => 1]
    ];
    
    $data = $test_data[$endpoint] ?? [];
    
    $response = $api->call_api($endpoint, $method, $data);
    
    if ($response) {
        echo $colors['green'] . "✓ Successo\n" . $colors['reset'];
    } else {
        echo $colors['red'] . "✗ Errore: " . $api->get_last_error() . "\n" . $colors['reset'];
    }
}

// Esecuzione
if (php_sapi_name() === 'cli') {
    if ($argc > 1) {
        $endpoint = $argv[1];
        $method = $argv[2] ?? 'GET';
        test_endpoint($endpoint, $method);
    } else {
        run_tests();
    }
} else {
    echo "<pre>";
    if (isset($_GET['endpoint'])) {
        test_endpoint($_GET['endpoint'], $_GET['method'] ?? 'GET');
    } else {
        run_tests();
    }
    echo "</pre>";
}